package br.com.joalherianamajoias.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JoalheriaNamajoiasApplicationTests {

	@Test
	void contextLoads() {
	}

}
