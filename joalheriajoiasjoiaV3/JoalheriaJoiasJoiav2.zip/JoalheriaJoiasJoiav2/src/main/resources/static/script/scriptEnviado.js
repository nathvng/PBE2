document.addEventListener("DOMContentLoaded", function () {
    alert("Seu formulário foi enviado com sucesso!");
	<a href="index.html" class="btn-cadastro">Ir para página inicial</a>
});
