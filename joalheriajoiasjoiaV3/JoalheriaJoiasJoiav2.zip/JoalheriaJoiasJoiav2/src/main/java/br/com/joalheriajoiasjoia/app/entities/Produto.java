package br.com.joalheriajoiasjoia.app.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "tb_produto")
public class Produto {

	// Atributos
			@Id
			@GeneratedValue(strategy = GenerationType.IDENTITY)
			@Column(name = "idProduto", nullable = false)
			private Long idProduto;
			
			@Column(name = "nomeProduto", unique = false)
			private String nomeProduto;
			
			@Column(name = "preco", nullable = false, length = 100)
			private double preco;
			
			@Column(name = "cor", nullable = false, length = 100, unique = false)
			private String cor;


//Construtores
	public Produto() {

	}
	public Produto(Long idProduto, String nomeProduto, double preco, String cor) {
		this.idProduto = idProduto;
		this.nomeProduto = nomeProduto;
		this.preco = preco;
		this.cor = cor;
	}
	
	public Long getIdProduto() {
		return idProduto;
	}
	public void setIdProduto(Long idProduto) {
		this.idProduto = idProduto;
	}
	public String getNomeProduto() {
		return nomeProduto;
	}
	public void setNomeProduto(String nomeProduto) {
		this.nomeProduto = nomeProduto;
	}
	public double getPreco() {
		return preco;
	}
	public void setPreco(double preco) {
		this.preco = preco;
	}
	public String getCor() {
		return cor;
	}
	public void setCor(String cor) {
		this.cor = cor;
	}
	
}